'use strict';

/**
 * @ngdoc service
 * @name miappApp.pokemonservice
 * @description
 * # pokemonservice
 * Service in the miappApp.
 */
angular.module('miappApp')
  .service('pokemonservice', function (Config, $q, $http) {
    // AngularJS will instantiate a singleton by calling "new" on this function

    function listado(){
    	var deferred = $q.defer();

      	$http.get(Config.POKE) //config
    		.then(function(response){

          console.log(response);
          
    			deferred.resolve(response);
    		});

    	 return deferred.promise;
    }

  

	return {
    	listado: listado,
    }



  });
