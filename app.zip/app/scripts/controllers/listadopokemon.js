'use strict';

/**
 * @ngdoc function
 * @name miappApp.controller:ListadopokemonCtrl
 * @description
 * # ListadopokemonCtrl
 * Controller of the miappApp
 */
angular.module('miappApp')
  .controller('ListadopokemonCtrl', 
  		function ($scope, pokemonservice, tiposervice) {
    
   $scope.mostrarpokemon = function(){
  			
		console.log('Se llamó a un pokemon'); 
  	 
   };
 
 


    pokemonservice.listado()
  			.then(function(response){
  				$scope.pokemones = response.data.results;
  			});
    

    tiposervice.listado()
  			.then(function(response){
  				$scope.tipos = response.data.results;
  			});





  });
